﻿using Microsoft.AspNetCore.Mvc;
using Tarea_02_cRazorPages.Models;

namespace Tarea_02_cRazorPages.Controllers
{
    
    [Route("Book")]
    public class BookController : Controller
    {
        private readonly ILogger<BookController> _logger;
        private readonly IBookRepository _BookRepository;

        private readonly IWebHostEnvironment _webRootPath; //IWebHostEnvironment es una interfaz que proporciona
        // información sobre el entorno web donde se está ejecutando la aplicación, como la ruta raíz de la aplicación, el
        // entorno actual (desarrollo, producción, etc.), y más.

        public BookController(ILogger<BookController> logger,
           IBookRepository repo,
            IWebHostEnvironment path)
        {
            _logger = logger;
            _BookRepository = repo;
            _webRootPath = path;
        }
        /************************************************************************************************************************/
        // https://localhost:7144/Book/GetAllBooks
        [Route("GetAllBooks")]
        public IActionResult GetAll()
        {
            // observar que explicitamente indico el nombre de la vista que quiero renderizar
            return View("GetAll", this._BookRepository.GetAllBooks());
        }


        /************************************************************************************************************************/

        // Este action se llama al realizar click desde el link Ver
        [HttpGet]
        [Route("Ver/{isbn}")]
        public IActionResult Ver(int isbn)
        {
            _logger.LogInformation($"Estoy en action Ver, isbn: {isbn}");

            if (isbn == null)
            {
                return NotFound("Debe especificar isbn");
            }

            var book = this._BookRepository.Get(isbn);

            if (book == null)
            {
                return NotFound($"Isbn no encontrado: {isbn}");
            }

            return View("Get", book);  // Cambia el nombre de la vista aquí
        }


        /************************************************************************************************************************/
        [HttpGet]
        [Route("Borrar/{isbn}")]
        public IActionResult Borrar(int isbn)
        {
            Book book;
            _logger.LogInformation($"Estoy en action Borrar, isbn: {isbn}");
            book = this._BookRepository.Get(isbn);
            if (isbn == null)
            {
                return NotFound($"Isbn no encontrado: {isbn}");
            }
            return View(book);
        }
        /************************************************************************************************************************/
        [HttpPost, ActionName("ConfirmarBorrado")]
        public IActionResult ConfirmarBorrado(int isbn)
        {
            _logger.LogInformation($"Estoy en action ConfirmarBorrardo, isbn: {isbn}");
            this._BookRepository.Delete(isbn);
            return RedirectToAction("GetAll", "Book");
        }

        /************************************************************************************************************************/
        
        [HttpGet]   //simplemente devuelve la vista vacía donde el usuario puede ingresar los detalles del vehículo.
        [Route("Crear")]
        public IActionResult Create()
        {
            return View();
        }
        /************************************************************************************************************************/

        [HttpPost]
        [Route("CrearBook")]
        public IActionResult CreateBook([Bind("isbn,titulo,autor,fecha")] Book book)
        {
            this._BookRepository.Add(book);
            return RedirectToAction("GetAll", "Book");
        }

        /*El atributo [Bind("isbn,titulo,autor,fecha")]: Este atributo especifica que solo los campos isbn, titulo, autor, y fecha
         * del modelo Book deben vincularse (o mapearse) desde los datos enviados en la solicitud. Si se envían otros datos en 
         * la solicitud, no se mapearán en la instancia del modelo Book.*/

        /************************************************************************************************************************/

        [HttpGet]
        [Route("Edit")]
        public IActionResult Editar(int isbn)
        {
            var book = _BookRepository.Get(isbn);
            if (isbn == null)
            {
                return NotFound($"Libro  con isbn {isbn} no encontrado.");
            }
            return View(book);
        }

        /************************************************************************************************************************/


        [HttpPost]
        [Route("EditBook")]
        public IActionResult EditBook([Bind("isbn,titulo,autor,fecha")] Book book)
        {
            if (ModelState.IsValid)
            {
                try
                {
                    _BookRepository.Update(book);
                    return RedirectToAction("GetAll", "Book");
                }
                catch (KeyNotFoundException ex)
                {
                    ModelState.AddModelError(string.Empty, ex.Message);
                }
            }
            return View("Editar", book);
        }


    }
}

﻿using System.Collections.Generic;
using Tarea_02_cRazorPages.Models;

namespace Tarea_02_cRazorPages.Data
{
    public class BookRepository : IBookRepository
    {
        private readonly Dictionary<int, Book> _books;

        public BookRepository()
        {
            // Inicialización del diccionario
            _books = new Dictionary<int, Book>();

            // Creación de los libros
            Book b1 = new Book(1, "Don Quijote de la Mancha", "Miguel de Cervantes", new DateOnly(1605, 1, 1));
            Book b2 = new Book(2, "1984", "George Orwell", new DateOnly(1949, 6, 8));
            Book b3 = new Book(3, "El Principito", "Antoine de Saint-Exupéry", new DateOnly(1943, 4, 6));
            Book b4 = new Book(4, "Matar a un ruiseñor", "Harper Lee", new DateOnly(1960, 7, 11));
            Book b5 = new Book(5, "Cien años de soledad", "Gabriel García Márquez", new DateOnly(1967, 5, 30));
            Book b6 = new Book(6, "Crimen y castigo", "Fiódor Dostoyevski", new DateOnly(1866, 1, 1));
            
            // Agregarlos al diccionario
            _books.Add(b1.isbn, b1);
            _books.Add(b2.isbn, b2);
            _books.Add(b3.isbn, b3);
            _books.Add(b4.isbn, b4);
            _books.Add(b5.isbn, b5);
            _books.Add(b6.isbn, b6);
         
        }
         public Dictionary<int, Book> GetAllBooks()
        {
            return _books;
        }
        public void Add(Book book)
        {
            this._books.Add(book.isbn, book);
        }
        public void Update(Book book)
        {
            if (_books.ContainsKey(book.isbn))
            {
                _books[book.isbn] = book;
            }
            else
            {
                throw new KeyNotFoundException("El libro con el ISBN especificado no existe.");
            }
        }
        public void Delete(int isbn)
        {
            this._books.Remove(isbn);
        }

        public Book Get(int isbn)
        {
            Book respuesta;
            //hay varias maneras de buscar un elemento en un map
            //la otra alternativa es _vehiculos[matricula] pero hay que realizar manejo de excepciones

            this._books.TryGetValue(isbn, out respuesta);
            return respuesta;
        }

    }
}

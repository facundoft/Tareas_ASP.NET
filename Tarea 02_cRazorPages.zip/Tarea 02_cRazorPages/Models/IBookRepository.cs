﻿namespace Tarea_02_cRazorPages.Models
{
    public interface IBookRepository
    {
        public Dictionary<int, Book> GetAllBooks();
        public void Add(Book book);
        public void Delete(int isbn);
        public Book Get(int isbn);
        public void Update(Book book);



    }
}

﻿using Microsoft.VisualBasic;

namespace Tarea_02_cRazorPages.Models
{
    public class Book
    {
        public int isbn { get; set; }
        public string titulo { get; set; }
        public string autor { get; set; }
        public DateOnly fecha { get; set; }
        public Book(int isbn, String titulo, String autor, DateOnly fecha)
        {
            this.isbn = isbn;
            this.titulo = titulo;
            this.autor = autor;
            this.fecha = fecha;
        }
        public Book(){}
    }
  

}
